def total(*n):
    result = 0

    for i in n:
        result += i

    return print(result)
