Korean = 70
English = 80
Math = 90

score = [Korean, English, Math]

total = sum(score)
average = sum(score) / len(score)

print('점수:', score)
print('총점:', total)
print('평균:', average)