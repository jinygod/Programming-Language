d = {
    '리스트':[1, 3, 5],
    '튜플':(1, 2, 3)
}

print(d)

d.clear()

print(d)