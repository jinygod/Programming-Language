s1 = set("13579")
s2 = set("12468")
s3 = s1 | s2
print('s1:', s1)
print('s2:', s2)
print('s3:', s3)