t = 1,3,5,7,9
print(t)
print(t[:4])
print(t[2:])
print(t[2:4])
print(t[:2])