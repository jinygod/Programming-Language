import re

# 전화번호
regtelex = r'\d{2,3}[-]?\d{3,4}[-]?\d{4}'

# 주민등록번호
regjumin = r'\d{6}[-]?\d{7}'
